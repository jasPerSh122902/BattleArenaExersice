# BattleArena
In this game, the player must survive three engagements with monsters in turn-based combat to win. Use this template as a starting point. Fill out the empty functions to make the game run as it does in the given reference.

Reference Build:
https://github.com/LodisAIE/BattleArenaExercise/releases/tag/1.0
